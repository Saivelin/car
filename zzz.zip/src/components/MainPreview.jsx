import React from 'react';

const MainPreview = () => {
    return (
        <div className='mainPreview'></div>

    );
};

export default MainPreview;