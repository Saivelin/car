
import Registered from "@/components/Registered";

const index = () => {
   return (
      <Registered></Registered>
   );
};

export default index;